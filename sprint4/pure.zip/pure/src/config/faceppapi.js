// https://console.faceplusplus.com.cn/documents/40608240
export default {
  api_key: '7sz5c2XbXG3Z1shhtZvb4zjvbYPEyq2',
  api_secret: 'L2xsMQmNpW7lCGv0dVViaJda0iMdETWB',
  image_base64: '',
  return_grayscale: 0,
}
