import ImgCutter from '../src/components/ImgCutter.vue'
export default ImgCutter
